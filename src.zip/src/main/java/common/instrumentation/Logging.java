package common.instrumentation;

public class Logging {

    // TODO: Figure out what we need here for investigation purposes
}