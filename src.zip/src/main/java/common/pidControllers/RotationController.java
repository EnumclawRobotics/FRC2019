package common.pidControllers;

/*
* handles keeping an arm at a position
*/
public class RotationController {
}