package common.pidControllers;

/* 
 * handles smoothing out the acceleration in a drive motor 
 */
public class DriveController {
    //TODO: needs code
}